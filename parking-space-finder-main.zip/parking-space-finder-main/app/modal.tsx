// app/modal.tsx
import { StyleSheet, Text, View } from 'react-native';

export default function ModalScreen() {
    return (
        <View style={styles.container}>
            <Text style={styles.title}>Modal</Text>
            <Text>This is an example modal screen.</Text>
        </View>
    );
}
const styles = StyleSheet.create({
    container: { flex: 1, padding: 16, gap: 8, justifyContent: 'center', alignItems: 'center' },
    title: { fontSize: 22, fontWeight: '700' },
});
